--Section 1. Querying data
--Basic SQL Server SELECT statement
SELECT
	*
FROM
	sales.customers;

--The following query finds the first name and last name of all customers.
SELECT 
	first_name,
	last_name
FROM
	sales.customers;

----The following query finds the first name , last name and email of all customers.
SELECT 
	first_name,
	last_name,
	email

FROM
	sales.customers;

--SQL Server Select  - retrive all columns and sort the resultset
SELECT
	*
FROM
	sales.customers;

--To filter rows bansed on one or more conditions, use WHERE clause
SELECT
	*
FROM
	sales.customers
WHERE
	state = 'CA';

--Sort the reuslt set based on first name using ORDER BY 
SELECT
	*
FROM
	sales.customers
WHERE
	state = 'CA'
ORDER BY
	first_name;

--Print all the cities of customers located in California and number of customers in each city.
SELECT
	city
FROM
	sales.customers
WHERE
	state = 'CA'
GROUP BY 
	city

SELECT
	city,
	count(city)
FROM
	sales.customers
WHERE
	state = 'CA'
GROUP BY 
	city

--Print all city in Califonia which has more than 10 customers in each city.
SELECT
	city,
	count(city)
FROM
	sales.customers
WHERE
	state = 'CA'
GROUP BY 
	city
HAVING
	count(city) > 10

--Section 2. Sorting Date
--SQL Server ORDER BY
--Sort a result set by one or more column in ascending order
--Sort the customer list by the first name in ascending order
SELECT
	first_name,
	last_name
FROM
	sales.customers
ORDER BY
	first_name

--Sort the customer list by first name in descending order
SELECT
	first_name,
	last_name
FROM
	sales.customers
ORDER BY
	first_name DESC;

--Sort a result set by multiple Columns
--Retrive the first name and last name and city of customer and sort by city and first name
SELECT
	city,
	first_name,
	last_name
FROM
	sales.customers;

SELECT
	city,
	first_name,
	last_name
FROM
	sales.customers
ORDER BY
	city,
	first_name

--Sort a result set by multiple columns and different orders
SELECT
	city,
	first_name,
	last_name
FROM
	sales.customers
ORDER BY
	city ASC,
	first_name DESC

--Sort a result set by a column that is not in the select list
--Sort the customers by state even though the state column does not appear in select 
SELECT 
	city,
	first_name,
	last_name
FROM
	sales.customers
ORDER BY
	state

--Using LEN() function in the ORDER BY clause to retrive a customer list sort 
--by the lendth of the first name.
SELECT 
	first_name,
	last_name,
	LEN(first_name)
FROM
	sales.customers
ORDER BY
	LEN(first_name)

--Section 3. Limiting Rows
--SQL Server OFFSET FETCH
SELECT 
	*
FROM
	production.products;

-- Write query to print all products from products table and sort the products 
--by their list price and product name
SELECT 
	product_name,
	list_price
FROM
	production.products
ORDER BY
	list_price,
	product_name

--Skip the first 10 products and return the rest by using OFFSET keyword
SELECT 
	product_name,
	list_price
FROM
	production.products
ORDER BY
	list_price,
	product_name
OFFSET 10 ROWS;

--Skip the first 10 products and select next 10 products using OFFSET and FETCH Clause
SELECT 
	product_name,
	list_price
FROM
	production.products
ORDER BY
	list_price,
	product_name
OFFSET 10 ROWS
FETCH NEXT 20 ROWS ONLY;

--To get the top 10 most expensive products you use both OFFSET and FETCH clauses
SELECT
	product_name,
	list_price
from 
	production.products
ORDER BY
	list_price desc,
	product_name
OFFSET 0 ROWS
FETCH FIRST 10 ROWS ONLY;

--Using TOP with constant value
--The following query uses a constant value to return the top 10 most expensive products
SELECT TOP 10 
	product_name,
	list_price
FROM
	production.products
ORDER BY
	list_price desc

--Using TOP to return a percentage of rows
--The following query uses PERCENT to specifiy the number of products returned in the result set.

SELECT  
	product_name,
	list_price
FROM
	production.products;


SELECT TOP 1 PERCENT  
	product_name,
	list_price
FROM
	production.products
ORDER BY
	list_price desc

--Section 4. Filerting data
--DISTINCT 
SELECT 
	city
FROM
	sales.customers;

--To get distinct cities using DISTINCT Keyword
SELECT DISTINCT
	city
FROM
	sales.customers;

--DISTINCT multiple columns
--Print all cities and state of all customers
SELECT
	city,
	state
FROM
	sales.customers
ORDER BY
	city,
	state

SELECT DISTINCT
	city,
	state
FROM
	sales.customers
ORDER BY
	city,
	state

--SQL Server WHERE example
--Write query which returns products that meet two conditions. category id is 1 and model is 2018
SELECT 
	*
FROM
	production.products
WHERE
	category_id = 1 AND model_year = 2018
ORDER BY
	list_price DESC;

--Display the products details whose list price is greater than 300 and model is 2018
SELECT 
	*
FROM
	production.products
WHERE
	list_price >300 AND model_year = 2018
ORDER BY
	list_price DESC;

--finds products whose list price is greater than 3,000 or model is 2018.
SELECT 
	*
FROM
	production.products
WHERE
	list_price >3000 OR model_year = 2018
ORDER BY
	list_price DESC;

--find the products whose list prices are between 1,899 and 1,999.99:
SELECT 
	*
FROM
	production.products
WHERE
	list_price BETWEEN 1899 AND 1999.99
ORDER BY
	list_price DESC;

SELECT    *FROM     production.productsWHERE     list_price >= 1899 AND list_price <= 1999.99ORDER BY    list_price DESC;

--find products whose list price is 299.99 or 466.99 or 489.99

SELECT    *FROM     production.productsWHERE     list_price = 299.99 OR list_price = 466.99 OR list_price = 489.99ORDER BY    list_price DESC;

SELECT 	* FROM 	production.products WHERE 	list_price IN (299.99, 466.99,489.99)ORDER BY 
	list_price DESC;

--find products whose name contains the string 'Cruiser'
SELECT
	*
FROM
	production.products
WHERE 
	product_name like '%Cruiser%'
ORDER BY
	list_price

SELECT
	*
FROM
	production.products
WHERE 
	product_name like 'T%'
ORDER BY
	list_price

SELECT
	*
FROM
	sales.customers;

SELECT
	*
FROM
	sales.customers
WHERE 
	first_name like 'J%';

SELECT
	DISTINCT CITY
FROM
	sales.customers
WHERE 
	city like '%er';

--Joins
--Inner Join - produces a data set that includes rows from the left table which have matching rows
--from the right table.
--First , create a new schema named hr
CREATE SCHEMA hr;

--Second , create two new tables named candidates and employees in the hr schema
drop table hr.candidates;
CREATE TABLE hr.candidates(
	id int,
	fullname varchar(100)
);

drop table hr.employees
CREATE TABLE hr.employees(
	id int,
	fullname varchar(100)
);

--Third , insert some rows into candidates and employees tables
INSERT INTO 
	hr.candidates(id,fullname)
values
	(1,'John Doe'),
	(2,'Lily Bush'),
	(3,'Peter Dructker'),
	(4,'Jane Doe')

INSERT INTO 
	hr.employees(id,fullname)
values
	(1,'John Doe'),
	(2,'Jane Doe'),
	(3,'Michael Scott'),
	(4,'Jack Sparrow')

--Four, Run select on Candidates and Employees

SELECT 
	* 
FROM
	hr.candidates;

SELECT 
	* 
FROM
	hr.employees;

--Inner Join
SELECT 
	c.id candidate_id,
	c.fullname candidate_name,
	e.id employee_id,
	e.fullname employee_name
FROM
	hr.candidates c
INNER JOIN
	hr.employees e
ON
	c.fullname = e.fullname

--SQL Server Left Join
SELECT 
	c.id candidate_id,
	c.fullname candidate_name,
	e.id employee_id,
	e.fullname employee_name
FROM
	hr.candidates c
LEFT JOIN
	hr.employees e
ON
	c.fullname = e.fullname


--SQL Server Right Join
SELECT 
	c.id candidate_id,
	c.fullname candidate_name,
	e.id employee_id,
	e.fullname employee_name
FROM
	hr.candidates c
RIGHT JOIN
	hr.employees e
ON
	c.fullname = e.fullname

--SQL Server Full Join
SELECT 
	c.id candidate_id,
	c.fullname candidate_name,
	e.id employee_id,
	e.fullname employee_name
FROM
	hr.candidates c
FULL JOIN
	hr.employees e
ON
	c.fullname = e.fullname

--Self Join
SELECT 
	*
FROM
	sales.staffs

SELECT 
	e.first_name + ' reports to '+ m.first_name employee_manager_details
FROM 
	sales.staffs e
INNER JOIN
	sales.staffs m
ON
	m.staff_id = e.manager_id;

--Data Defination - DDL
--Query to create new database named as TestDB;
CREATE DATABASE testDB;

--Query to lists all database in the SQL Server
SELECT 
	name
FROM
	master.sys.databases;

EXEC sp_databases;

--Query to DROP Database
DROP DATABASE IF EXISTS testDB;

--SQL Server CREATE SCHEMA
CREATE SCHEMA customer_services;
GO

--SQL Server DROP SCHEMA
DROP SCHEMA customer_services;

--SQL Server CREATE TABLE
--SQL Server IDENTITY example
CREATE TABLE hr.person(
	person_id int IDENTITY(1,1),
	first_name varchar(50),
	last_name varchar(50),
	gender char(1)
);

SELECT 
	* 
FROM
	hr.person;

--INSERT 
INSERT INTO hr.person(first_name,last_name,gender)
VALUES('Anirudha' , 'Soni' , 'M');
INSERT INTO hr.person(first_name,last_name,gender)
VALUES('Aman' , 'Agarwal' , 'M');

--Creating SEQUENCE
CREATE SEQUENCE item_counter
	AS INT
	START WITH 1
	INCREMENT BY 10;

SELECT NEXT VALUE FOR item_counter;

--Using a sequnece object in a single table.
--First ,  create new schema
CREATE SCHEMA procurment;

--Second , create new table named as orders
CREATE TABLE procurment.purchase_orders(
	order_id int,
	vendor_id int,
	order_date date
);

--create a new sequence object named order_number whta starts with 1 and increment by 1
CREATE SEQUENCE procurment.order_number
	AS INT
	START WITH 1
	INCREMENT BY 1;

SELECT 
	*
FROM
	procurment.purchase_orders;

--INSERT three rows into the table and use values generated by sequence
INSERT INTO procurment.purchase_orders (order_id, vendor_id, order_date)
VALUES(NEXT VALUE FOR procurment.order_number , 1 , '2021-06-25');
INSERT INTO procurment.purchase_orders (order_id, vendor_id, order_date)
VALUES(NEXT VALUE FOR procurment.order_number ,2 , '2021-06-24');
INSERT INTO procurment.purchase_orders (order_id, vendor_id, order_date)
VALUES(NEXT VALUE FOR procurment.order_number , 1 , '2021-06-23');

--SQL Server ALTER TABLE ADD Column
--First Create Table
DROP TABLE sales.quitations
CREATE TABLE sales.quotations(
	quotation_no int IDENTITY,
	valid_from date,
	valid_to date
);

SELECT * FROM sales.quotations;

--Add New column named description to table using ALTER TABLE
ALTER TABLE sales.quotations
ADD description VARCHAR(255);

--ALETER TABLE ALTER COLUMN
--Change the size of description column
ALTER TABLE sales.quotations 
ALTER COLUMN description varchar(50);

--ALTER TABLE DROP COLUMN
ALTER TABLE sales.quotations
DROP COLUMN description;

--SQL Server Computed Columns
SELECT 
	*
FROM 
	[production].[products];

SELECT 
	list_price ,
	list_price - 50 discounted_price
FROM 
	[production].[products];

--DROP Table

DROP TABLE sales.quotations;
SELECT * FROM sales.quotations;	

--TRUNCATE TABLE 
--First , create a table
CREATE TABLE customer_groups
(
	group_id int identity,
	group_name varchar(20)
);

--Insert 
INSERT INTO customer_groups (group_name)
VALUES
	('Intercompany'),
	('Third Party'),
	('One time')

SELECT * FROM customer_groups;

--If you want to delete data of your table
	--DELETE
	--TRUNCATE

--USING DELETE
DELETE FROM customer_groups;
--USING TRUNCATE
TRUNCATE TABLE customer_groups;

--TRUNCATE VS DELETE
--The truncate table has the following advantages over delete statement

--1. Use less transaction log. (Make my delete transaction fast)
--2. Identity reset
--3. Use fewer locks

--SELECT Statement
SELECT 
	product_name ,
	list_price
FROM 
	[production].[products]

--SELECT INTO Statement
SELECT 
	product_name ,
	list_price
INTO #temp_product_price --temporary table
FROM 
	[production].[products]


SELECT
	* 
FROM
	#temp_product_price;

--RENAME table

CREATE TABLE sales.contr(
	contract_no int,
	start_date date,
	expired_date date
);

SELECT * FROM sales.contracts;

EXEC sp_rename 'sales.contr' ,'contracts';
--SQL Server Primary key
CREATE TABLE procurment.vendor_groups(
	group_id int IDENTITY PRIMARY KEY,
	group_name varchar(20)
);

INSERT INTO procurment.vendor_groups(group_name)
VALUES ('Third-Party Vendors'),
('Interco Vendors'),
('One-time Vendors')



--foreign key
CREATE TABLE procurment.vendors(
	vendor_id int identity primary key,
	vandor_name varchar(100),
	group_id int,
	CONSTRAINT fk_group FOREIGN KEY(group_id)
	REFERENCES procurment.vendor_groups(group_id)
);

SELECT * FROM procurment.vendor_groups;
SELECT * FROM procurment.vendors;

INSERT INTO procurment.vendors (vandor_name,group_id)
VALUES('abc corp' , 1);

INSERT INTO procurment.vendors (vandor_name,group_id)
VALUES('bpl corp' , 1);

INSERT INTO procurment.vendors (vandor_name,group_id)
VALUES('bpl corp' , 3);

INSERT INTO procurment.vendors (vandor_name,group_id)
VALUES('bpl corp' , 4);

--NOT NULL and CHECK CONSTRAINT
CREATE SCHEMA test;
GO

CREATE TABLE test.products(
    product_id INT IDENTITY PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    unit_price INT CHECK(unit_price > 0)
);

--test not null constraint
INSERT INTO test.products(product_name,unit_price) VALUES(NULL , 10);
INSERT INTO test.products(product_name,unit_price) VALUES('Nirma' , 10);

--test check constraint
INSERT INTO test.products(product_name,unit_price) VALUES('Lux' , 1);

select * from test.products;
