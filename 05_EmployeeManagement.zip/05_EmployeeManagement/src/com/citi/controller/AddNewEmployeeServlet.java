package com.citi.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.citi.dao.EmployeeDAO;
import com.citi.pojo.Employee;

@WebServlet("/AddNewEmployeeServlet")
public class AddNewEmployeeServlet extends HttpServlet {

	private int employeeId;
	private String name;
	private double salary;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		employeeId = Integer.valueOf(request.getParameter("txtEmployeeId"));
		name = request.getParameter("txtName");
		salary = Double.valueOf(request.getParameter("txtSalary"));

		Employee employee = new Employee(employeeId, name, salary);

		System.out.println(employee);

		// code to insert data into database
		EmployeeDAO dao = new EmployeeDAO();
		//dao.testDBConnection();
		dao.addNewEmployee(employee);
		
		// redirect to home page
		response.sendRedirect("employeeHome.jsp");

	}

}
