package com.citi.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.citi.dao.EmployeeDAO;
import com.citi.pojo.Employee;
@WebServlet("/UserNavigationServlet")
public class UserNavigationServlet extends HttpServlet {

	private String navigationPath;
	private int employeeId;
	private Employee employee;
	private EmployeeDAO dao;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		navigationPath = request.getParameter("navigation");
		
		dao = new EmployeeDAO();
		HttpSession session = request.getSession();
		
		
		System.out.println("Selected employeeId :: " + employeeId);
		switch (navigationPath) {
		case "Add Employee":
			response.sendRedirect("addNewEmployee.html");
			break;
		case "Update Employee":
			employeeId = Integer.valueOf(request.getParameter("employeeId"));
			session.setAttribute("employeeId",employeeId);
			employee = dao.getEmployeeByEmployeeId(employeeId);
			session.setAttribute("employee", employee);
			response.sendRedirect("updateEmployee.jsp");
			break;	
		case "Delete Employee":
			employeeId = Integer.valueOf(request.getParameter("employeeId"));
			session.setAttribute("employeeId",employeeId);
			dao.deleteEmployee(employeeId);
			response.sendRedirect("employeeHome.jsp");
			break;
		default:
			break;
		}
	} 
}
