package com.citi.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.citi.pojo.Employee;

public class EmployeeDAO {

	private String user = "SYSTEM";
	private String password = "Oracle123$";
	private String url = "jdbc:oracle:thin:@localhost:1521:xe";
	private String driverClass = "oracle.jdbc.driver.OracleDriver";
	private String sql;

	private Connection connection;
	private PreparedStatement preparedStatement;
	private ResultSet resultSet;

	public boolean deleteEmployee(int employeeId) {
		try {
			Class.forName(driverClass);
			connection = DriverManager.getConnection(url, user, password);
			sql = "delete from employee_master where employee_id=?";
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, employeeId);

			int count = preparedStatement.executeUpdate();
			System.out.println("Count :: " + count);
			if (count > 0)
				return true;

		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return false;
	}
	
	public boolean updateEmployee(Employee employee) {
		try {
			Class.forName(driverClass);
			connection = DriverManager.getConnection(url, user, password);
			sql = "update employee_master set name=? , salary=? where employee_id=?";
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, employee.getName());
			preparedStatement.setDouble(2, employee.getSalary());
			preparedStatement.setInt(3, employee.getEmployeeId());

			int count = preparedStatement.executeUpdate();
			System.out.println("Count :: " + count);
			if (count > 0)
				return true;

		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return false;	
	}
	
	public Employee getEmployeeByEmployeeId(int employeeId) {
		try {
			Class.forName(driverClass);
			connection = DriverManager.getConnection(url, user, password);
			sql = "select * from employee_master where employee_id=?";
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, employeeId);
			resultSet = preparedStatement.executeQuery();

			Employee employee = new Employee();
			if (resultSet.next()) {

				employee.setEmployeeId(resultSet.getInt("employee_id"));
				employee.setName(resultSet.getString("name"));
				employee.setSalary(resultSet.getDouble("salary"));

				
			}
			return employee;
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	
 	public List<Employee> employeesList() {

		try {
			Class.forName(driverClass);
			connection = DriverManager.getConnection(url, user, password);
			sql = "select * from employee_master";
			preparedStatement = connection.prepareStatement(sql);
			resultSet = preparedStatement.executeQuery();

			List<Employee> employeesList = new ArrayList<>();
			while (resultSet.next()) {
				Employee employee = new Employee();
				employee.setEmployeeId(resultSet.getInt("employee_id"));
				employee.setName(resultSet.getString("name"));
				employee.setSalary(resultSet.getDouble("salary"));

				employeesList.add(employee);
			}
			return employeesList;
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public boolean addNewEmployee(Employee employee) {

		try {
			Class.forName(driverClass);
			connection = DriverManager.getConnection(url, user, password);
			sql = "insert into employee_master values(?,?,?)";
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, employee.getEmployeeId());
			preparedStatement.setString(2, employee.getName());
			preparedStatement.setDouble(3, employee.getSalary());

			int count = preparedStatement.executeUpdate();
			System.out.println("Count :: " + count);
			if (count > 0)
				return true;

		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return false;
	}

}
