package com.seclore.service;

public interface MessageInterface {
	public void sendMessage(String to, String message);
}
