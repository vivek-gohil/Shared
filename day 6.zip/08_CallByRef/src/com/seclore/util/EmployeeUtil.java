package com.seclore.util;

import com.seclore.pojo.Employee;

public class EmployeeUtil {
	public void changeEmployee(Employee employee) throws CloneNotSupportedException {
		System.out.println("EmployeUtil start");
		Employee localEmployee = (Employee) employee.clone();
		System.out.println(localEmployee);
		localEmployee.setName(localEmployee.getName().toUpperCase());
		localEmployee.setSalary(localEmployee.getSalary() + 1000);
		System.out.println(localEmployee);
		System.out.println("EmployeUtil end");
	}
}
