package com.seclore.pojo;

public class dispenserType {
	private int numberOfItems, cost;

	public dispenserType() {
		numberOfItems = 50;
		cost = 50;
	}

	public dispenserType(int numberOfItems, int cost) {
//	super();
		this.numberOfItems = numberOfItems;
		this.cost = cost;
	}

	public int getNoOfItems() {
		return numberOfItems;
	}

	public int getCost() {
		return cost;
	}

	public void makeSale() {
		numberOfItems--;
	}

}
