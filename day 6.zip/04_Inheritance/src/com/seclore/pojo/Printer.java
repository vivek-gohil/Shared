package com.seclore.pojo;

public interface Printer {
	void print();
}
