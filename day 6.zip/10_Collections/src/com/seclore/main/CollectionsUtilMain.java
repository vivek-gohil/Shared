package com.seclore.main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.seclore.pojo.Employee;
import com.seclore.util.EmployeeNameCompartor;

public class CollectionsUtilMain {
	public static void main(String[] args) {

		Employee employee = new Employee(101, "Vivek", 1000);
		Employee employee2 = new Employee(102, "Divya", 2000);
		Employee employee3 = new Employee(103, "Vinayak", 1000);

		List<Employee> employees = new ArrayList<Employee>();

		Collections.addAll(employees, employee, employee2, employee3);

		Iterator<Employee> employeeIterator = employees.iterator();

		while (employeeIterator.hasNext()) {
			Employee empTemp = (Employee) employeeIterator.next();
			System.out.println(empTemp);
		}

		System.out.println(employees);

		Collections.sort(employees, new EmployeeNameCompartor());

		System.out.println(employees);

		int index = Collections.binarySearch(employees, employee3, new EmployeeNameCompartor());
		System.out.println("Index :: " + index);

		List<Employee> newEmployees = new ArrayList<Employee>();
		System.out.println(newEmployees.size());
		Collections.addAll(newEmployees, new Employee(), new Employee(), new Employee());

		System.out.println("Calling copy");
		Collections.copy(newEmployees, employees);

		System.out.println(newEmployees);
	}
}
