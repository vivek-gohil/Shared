package com.seclore.main;

import java.util.ArrayList;
import java.util.List;

import com.seclore.dao.EmployeeDAO;
import com.seclore.pojo.Employee;

public class ArrayListMain {

	public static void main(String[] args) {

		Employee employee = new Employee(101, "Vivek", 1000);
		Employee employee2 = new Employee(102, "Divya", 2000);
		Employee employee3 = new Employee(101, "Vivek", 1000);

		EmployeeDAO dao = new EmployeeDAO(new ArrayList<Employee>());

		System.out.println("Adding Employees into ArrayList");
		dao.addNewEmployee(employee);
		dao.addNewEmployee(employee2);
		dao.addNewEmployee(employee3);

		System.out.println("Retriving Employees from ArrayList");
		List<Employee> employeeList = dao.getAllEmployees();

		for (Employee emp : employeeList) {
			System.out.println(emp);
		}

		

	}
}
