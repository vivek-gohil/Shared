package com.seclore.main;

import java.io.File;
import java.util.Scanner;

import com.seclore.util.FileInputStreamUtil;

public class FileInputStreamMain {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		FileInputStreamUtil fileInputStreamUtil = new FileInputStreamUtil();

		File file;
		String path;
		byte[] data;

		System.out.println("Please enter path to read file");
		path = scanner.next();
		file = new File(path);
		data = fileInputStreamUtil.readFile(file);

		for (byte b : data) {
			System.out.print((char) b);
		}
		scanner.close();

	}

}
