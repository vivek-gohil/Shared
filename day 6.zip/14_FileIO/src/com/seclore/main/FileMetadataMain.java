package com.seclore.main;

import java.io.File;

import com.seclore.util.PrintFileMetadataUtil;

public class FileMetadataMain {
	public static void main(String[] args) {
		File file = new File("../details.txt");
		PrintFileMetadataUtil metadata = new PrintFileMetadataUtil(file);

		metadata.printMetadataOfFile();
	}
}
