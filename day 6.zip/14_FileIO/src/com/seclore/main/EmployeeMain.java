package com.seclore.main;

import java.io.File;

import com.seclore.pojo.Employee;
import com.seclore.util.EmployeeUtil;

public class EmployeeMain {
	public static void main(String[] args) {
		Employee employee = new Employee(101, "Test Employee", 1000);
		File file = new File("c:/javafileio/serial.txt");

		EmployeeUtil employeeUtil = new EmployeeUtil();
		System.out.println(employeeUtil.employeeSerialization(file, employee) ? "Please check your file"
				: "Failed to serialize employee object");

		System.out.println("________________________________________________");

		System.out.println(employeeUtil.employeeDeserialization(file));
	}
}
