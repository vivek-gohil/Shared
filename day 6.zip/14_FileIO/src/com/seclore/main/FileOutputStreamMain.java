package com.seclore.main;

import java.io.File;
import java.util.Scanner;

import com.seclore.util.FileOutputStreamUtil;

public class FileOutputStreamMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		FileOutputStreamUtil fileOutputStreamUtil = new FileOutputStreamUtil();

		File file;
		String path;
		String data;

		System.out.println("Please enter path to write file");
		path = scanner.next();
		file = new File(path);
		scanner.nextLine();
		System.out.println("Enter data for file");
		data = scanner.nextLine();
		System.out.println(fileOutputStreamUtil.writeFile(file, data.getBytes()) ? "Please check your file"
				: "Failed to write file");

		scanner.close();
	}
}
