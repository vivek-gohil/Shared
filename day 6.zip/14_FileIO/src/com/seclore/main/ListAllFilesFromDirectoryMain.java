package com.seclore.main;

import java.io.File;

import com.seclore.util.ListAllFilesFromDirectoryUtil;
import com.seclore.util.PrintFileMetadataUtil;

public class ListAllFilesFromDirectoryMain {
	public static void main(String[] args) {
		File file = new File("c:/windows");

		ListAllFilesFromDirectoryUtil allFilesFromDirectoryUtil = new ListAllFilesFromDirectoryUtil(file);
		PrintFileMetadataUtil fileMetadataUtil;

		for (File fileTemp : allFilesFromDirectoryUtil.getFilesListFromDirectory()) {
			//System.out.println("Name :: " + fileTemp.getName() + " , Size :: " + fileTemp.length() + " bytes");
			fileMetadataUtil = new PrintFileMetadataUtil(fileTemp);
			fileMetadataUtil.printMetadataOfFile();
			System.out.println();
		}
	}
}
