package com.seclore.main;

import java.io.File;
import java.util.Scanner;

import com.seclore.util.FileWriterUtil;

public class FileWriterMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		// FileOutputStreamUtil fileOutputStreamUtil = new FileOutputStreamUtil();
		FileWriterUtil fileWriterUtil = new FileWriterUtil();

		File file;
		String path;
		String data;

		System.out.println("Please enter path to write file");
		path = scanner.next();
		file = new File(path);
		scanner.nextLine();
		System.out.println("Enter data for file");
		data = scanner.nextLine();
		System.out.println(
				fileWriterUtil.writeFile(file, data.toCharArray()) ? "Please check your file" : "Failed to write file");

		scanner.close();
	}
}
