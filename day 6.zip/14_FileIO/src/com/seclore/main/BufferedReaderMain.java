package com.seclore.main;

import java.io.File;
import java.util.Scanner;

import com.seclore.util.BufferedReaderUtil;

public class BufferedReaderMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		BufferedReaderUtil bufferedReaderUtil = new BufferedReaderUtil();

		File file;
		String path;
		String data;

		System.out.println("Please enter path to read file");
		path = scanner.next();
		file = new File(path);
		data = bufferedReaderUtil.readFile(file);

		System.out.println(data);
		scanner.close();
	}

}
