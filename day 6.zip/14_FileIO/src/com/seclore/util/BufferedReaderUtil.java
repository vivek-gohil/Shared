package com.seclore.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class BufferedReaderUtil {
	private BufferedReader reader;
	private StringBuilder data;

	public String readFile(File file) {
		try {
			reader = new BufferedReader(new FileReader(file));
			data = new StringBuilder("");
			String temp = reader.readLine();
			while (temp != null) {
				// data = data + temp + "\n";
				data.append(temp + "\n");
				temp = reader.readLine();
			}
		} catch (FileNotFoundException e) {
			System.out.println("File Not Found");
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println("IO Exception");
			System.out.println(e.getMessage());
		} finally {
			try {
				reader.close();
			} catch (IOException e) {
				System.out.println("Failed to close reader");
				System.out.println(e.getMessage());
			}
		}
		return data.toString();
	}
}
