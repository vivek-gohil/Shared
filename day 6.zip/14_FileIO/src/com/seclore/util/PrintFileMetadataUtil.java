package com.seclore.util;

import java.io.File;
import java.io.IOException;
import java.util.Date;

public class PrintFileMetadataUtil {
	private File file;

	public PrintFileMetadataUtil(File file) {
		this.file = file;
	}

	public void printMetadataOfFile() {
		try {
			if (file.exists()) {
				System.out.print("File Name :: " + file.getName() + " , ");
				System.out.print("Location/AbsolutePath :: " + file.getAbsolutePath() + " , ");
				System.out.print("ConicalPath :: " + file.getCanonicalPath() + " , ");
				System.out.print("Size :: " + file.length() + " bytes" + " , ");
				System.out.print("Parent Folder :: " + file.getParent() + " , ");
				Date modifiedDate = new Date(file.lastModified());
				System.out.print("File last modified :: " + modifiedDate + "\n");
			} else {
				System.out.println("Invalid File Path");
				System.out.println("File dosenot exist!!");
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}
}
