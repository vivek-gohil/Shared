package com.seclore.util;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ListAllFilesFromDirectoryUtil {
	private File file;

	public ListAllFilesFromDirectoryUtil(File file) {
		this.file = file;
	}

	public List<File> getFilesListFromDirectory() {
		List<File> filesList = new ArrayList<File>();
		File[] files;

		if (file.exists() && file.isDirectory()) {
			// FileFilterUtil fileFilterUtil = new FileFilterUtil();
			files = file.listFiles(new FileFilter() {
				@Override
				public boolean accept(File file) {
					return file.isFile() && file.getName().endsWith(".exe");
				}
			});
			filesList = Arrays.asList(files);
		}
		return filesList;
	}

}
