package com.seclore.main;

public class StringVsStringBufferMainV2 {

	public static String concatUsingString() {
		String message = "I Love";

		int i = 0;
		while (i < 10000) {
			message = message + "Java";
			i++;
		}
		return message;
	}

	public static StringBuffer concatUsingStringBuffer() {
		StringBuffer message = new StringBuffer("I Love");

		int i = 0;
		while (i < 10000) {
			message.append("Java");
			i++;
		}

		return message;
	}

	public static void main(String[] args) {
		long startTime = System.currentTimeMillis();
		concatUsingString();
		long endTime = System.currentTimeMillis() - startTime;
		System.out.println("Time taken by concating with String :: " + endTime + " ms");

		System.out.println();

		startTime = System.currentTimeMillis();
		concatUsingStringBuffer();
		endTime = System.currentTimeMillis() - startTime;
		System.out.println("Time taken by concating with StringBuffer :: " + endTime + " ms");
	}
}
