package com.seclore.main;

public class StringVsStringBufferMainV1 {
	public static void main(String[] args) {

//		String message1 = new String("I Love Java");
//		String message2 = "I Love Java";
//
//		System.out.println("message hashcode :: " + message1.hashCode());
//		System.out.println("message1 hashcode :: " + message2.hashCode());

//		String message = "I Love Java";
//		System.out.println(message);
//		System.out.println("HashCode :: " + message.hashCode());
//
		System.out.println();
//
//		message = message.concat(" , Java is best programming language");
//		System.out.println(message);
//		System.out.println("HashCode :: " + message.hashCode());

		StringBuffer message = new StringBuffer("I Love Java");
		System.out.println(message);
		System.out.println("HashCode :: " + message.hashCode());
//
		System.out.println();
//
//		// message = message.concat(" , Java is best programming language");
		message = message.append(" , Java is best programming language");
		System.out.println(message);
		System.out.println("HashCode :: " + message.hashCode());

	}
}
