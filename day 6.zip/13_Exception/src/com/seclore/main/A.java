package com.seclore.main;

public class A {
	protected void print() {
		System.out.println("Hi");
	}
	
	public void show() {
		System.out.println("Hello");
	}
}
class B extends A{
	public void print() {
		// TODO Auto-generated method stub
		super.print();
	}
	
	@Override
	protected void show() {
		// TODO Auto-generated method stub
		super.show();
	}
}
