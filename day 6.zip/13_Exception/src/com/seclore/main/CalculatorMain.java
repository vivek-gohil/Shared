package com.seclore.main;

import java.io.FileNotFoundException;
import java.util.Calendar;

import com.seclore.util.Calculator;

public class CalculatorMain {
	public static void main(String[] args) {
		Calculator calculator = new Calculator();

		calculator.acceptNumber();
		calculator.calculateResult();
		calculator.displayResult();
		
	}
}
