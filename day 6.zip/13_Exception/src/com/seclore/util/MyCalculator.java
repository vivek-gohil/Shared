package com.seclore.util;

import java.io.FileNotFoundException;
import java.io.IOException;

public class MyCalculator extends Calculator {

	public void test() throws FileNotFoundException, ClassNotFoundException {
		// TODO Auto-generated method stub
		super.test();
	}
}
