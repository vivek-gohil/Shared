package com.seclore.exceptions;

public class InvalidProductPriceException extends Exception {

	public InvalidProductPriceException() {
		System.out.println("InvalidProductPriceException object created!");
	}

	@Override
	public String getMessage() {
		return "Invalid price , product price must be > 0";
	}

}
