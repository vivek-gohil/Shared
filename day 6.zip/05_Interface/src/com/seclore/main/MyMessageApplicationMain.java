package com.seclore.main;

import java.util.Scanner;

import com.seclore.application.MyMessageApplication;
import com.seclore.factory.ApplicationMessageServiceFactory;
import com.seclore.service.EmailMessageService;
import com.seclore.service.MessageService;
import com.seclore.service.SMSMessageService;

public class MyMessageApplicationMain {
	public static void main(String[] args) {

		int choice;
		String message;
		String to;
		Scanner scanner = new Scanner(System.in);
		MyMessageApplication application;

		System.out.println("1.Simple Message");
		System.out.println("2.SMS Message");
		System.out.println("3.Email Message");
		System.out.println("Enter your choice");
		choice = scanner.nextInt();

		ApplicationMessageServiceFactory factory = new ApplicationMessageServiceFactory();
		application = factory.getApplicationMessageService(choice);

		scanner.nextLine();

		System.out.println("Enter Message");
		message = scanner.nextLine();

		System.out.println("Enter to");
		to = scanner.next();

		application.processMessage(to, message);

	}

}
