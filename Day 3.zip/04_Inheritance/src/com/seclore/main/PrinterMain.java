package com.seclore.main;

import java.util.Scanner;

import com.seclore.pojo.Canon110;
import com.seclore.pojo.CustomPageSize;
import com.seclore.pojo.HP3536;
import com.seclore.pojo.Printer;

public class PrinterMain {
	public static void main(String[] args) {		
		Printer printer;
		int printerType;
		Scanner scanner = new Scanner(System.in);

		System.out.println("Menu");
		System.out.println("1.Laser Printer = HP3536");
		System.out.println("2.Dot Matrix Printer = Canon110");
		System.out.println("Select the printer");
		printerType = scanner.nextInt();
		
		printer = printerFactory(printerType);
		printer.print();
		
		if(printer instanceof CustomPageSize) {
			((CustomPageSize) printer).changePageSize();
		}
		
	}

	public static Printer printerFactory(int printerType) {
		if (printerType == 1)
			return new HP3536();
		if (printerType == 2)
			return new Canon110();
		else
			return null;
	}
}
