package com.seclore.pojo;

public class HP3536 implements Printer, CustomPageSize {
	@Override
	public void print() {
		System.out.println("laser printer");
		System.out.println("HP3536 is printing");
	}

	@Override
	public void changePageSize() {
		System.out.println("Setting custom page size using HP3536");
	}
}
