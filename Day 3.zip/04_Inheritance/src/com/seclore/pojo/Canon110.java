package com.seclore.pojo;

public class Canon110 implements Printer {
	@Override
	public void print() {
		System.out.println("dot matrix printer");
		System.out.println("Canon110 is printing");
	}
}
