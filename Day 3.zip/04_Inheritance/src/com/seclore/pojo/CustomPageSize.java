package com.seclore.pojo;

public interface CustomPageSize {
	void changePageSize();
}
