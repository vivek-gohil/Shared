package com.seclore.main;

import com.seclore.test.MyClass;

public class MyClassMain {
	public static void main(String[] args) {
		MyClass obj = new MyClass();
		obj.display();
		System.out.println("___________________________");
		MyClass.display();
		System.out.println("___________________________");
		MyClass obj2 = new MyClass();
		obj2.display();
	}
}
