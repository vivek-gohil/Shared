package com.seclore.main;

import java.util.Scanner;

import com.seclore.pojo.Account;
import com.seclore.pojo.Current;
import com.seclore.pojo.Savings;

public class AccountMainV7 {
	public static void main(String[] args) {
		int accountNumber;
		String name;
		double balance;
		int choice;
		double amount;
		String continueChoice;
		boolean isSalary;
		int accountChoice;

		// Account account;
		Account account = null;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Menu");
		System.out.println("1.Savings");
		System.out.println("2.Current");
		System.out.println("Enter your choice");
		accountChoice = scanner.nextInt();

		System.out.println("Enter Account Details");
		// autogenerate account number
		System.out.println("Enter Name");
		name = scanner.nextLine();
		switch (accountChoice) {
		case 1:
			System.out.println("Do you want to open Salary account true||false");
			isSalary = scanner.nextBoolean();
			account = new Savings(0, name, 1500, isSalary);
			break;
		case 2:
			account = new Current(0, name, 0, 50000);
			break;
		default:
			System.out.println("Invalid Choice");
			System.exit(0);
			break;
		}
		do {
			System.out.println("Account Details");
			System.out.println("Generated Account Number :: " + account.getAccountNumber());
			System.out.println("Menu");
			System.out.println("1. Get Account Balance");
			System.out.println("2.Withdraw");
			System.out.println("3.Deposit");

			System.out.println("Enter your choice");
			choice = scanner.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Balance :: " + account.getBalance());
				break;
			case 2:
				System.out.println("Enter amount to withdraw");
				amount = scanner.nextDouble();
				System.out.println(account.withdraw(amount) ? "Transaction Success" : "Transaction Failed");
				System.out.println("Balance :: " + account.getBalance());
				break;
			case 3:
				System.out.println("Enter amount to deposit");
				amount = scanner.nextDouble();
				System.out.println(account.deposit(amount) ? "Transaction Success" : "Transaction Failed");
				System.out.println("Balance :: " + account.getBalance());
				break;
			default:
				System.out.println("Invalid choice");
				break;
			}
			System.out.println("Do you want to continue?");
			continueChoice = scanner.next();
		} while (continueChoice.equalsIgnoreCase("yes"));

	}
}
