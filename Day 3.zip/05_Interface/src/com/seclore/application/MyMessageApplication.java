package com.seclore.application;

import com.seclore.service.MessageInterface;

public class MyMessageApplication {

	private MessageInterface message;

	public MyMessageApplication(MessageInterface message) {
		this.message = message;
	}

	public void processMessage(String to, String message) {
		this.message.sendMessage(to, message);
	}
}
