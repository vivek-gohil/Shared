package com.seclore.factory;

import com.seclore.application.MyMessageApplication;
import com.seclore.service.EmailMessageService;
import com.seclore.service.MessageInterface;
import com.seclore.service.MessageService;
import com.seclore.service.SMSMessageService;

public class ApplicationMessageServiceFactory {

	private MessageInterface message;
	private MyMessageApplication application;

	public MyMessageApplication getApplicationMessageService(int typeOfMessage) {
		switch (typeOfMessage) {
		case 1:
			message = new MessageService();
			application = new MyMessageApplication(message);
			break;
		case 2:
			message = new SMSMessageService();
			application = new MyMessageApplication(message);
			break;
		case 3:
			message = new EmailMessageService();
			application = new MyMessageApplication(message);
			break;
		default:
			System.out.println("Invalid choice");
			break;
		}
		return application;
	}
}
