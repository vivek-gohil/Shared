package com.seclore.service;

public class EmailMessageService implements MessageInterface {
	public void sendMessage(String to, String message) {
		System.out.println("Sending Email " + message + ", To " + to);
	}
}
