package com.seclore.service;

public class SMSMessageService implements MessageInterface {
	public void sendMessage(String to, String message) {
		System.out.println("Sending SMS " + message + ", To " + to);
	}
}
