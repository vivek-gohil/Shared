package com.seclore.service;

public class MessageService implements MessageInterface{
	public void sendMessage(String to, String message) {
		System.out.println("Sending " + message + ", To " + to);
	}
	
	public void print() {
		System.out.println("Hello World :: Java 8");
	}
}
