package com.citi.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.citi.pojo.Employee;

public class EmployeeMain {
	public static void main(String[] args) {
		System.out.println("Start");

		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");

		Employee employee = applicationContext.getBean("employee", Employee.class);
		System.out.println("hashCode of employee :: " + employee.hashCode());

		Employee employee2 = applicationContext.getBean("employee", Employee.class);
		System.out.println("hashCode of employee2 :: " + employee2.hashCode());
		
		employee.getPermanentAddress().setStreet("A-4545");
		employee.getPermanentAddress().setCity("Mumbai");
		employee.getPermanentAddress().setState("Maharashtra");

		System.out.println(employee);

		System.out.println("End");
	}
}
