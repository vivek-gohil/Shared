package com.citi.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.citi.pojo.Message;

public class MessageMain {
	public static void main(String[] args) {
		System.out.println("Start");

		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");

		System.out.println("Injecting Message Object in main");
		Message message = applicationContext.getBean("msg", Message.class);
		message.setMessage("Hello");
		message.setTo("Vivek Gohil");
		message.setFrom("Supin");
		
		System.out.println(message);

		System.out.println("End");
	}
}
