package com.citi.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.citi.factory.ApplicationContextFactory;
import com.citi.pojo.Message;

public class MessageMain {
	public static void main(String[] args) {
		System.out.println("Start");

//		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");

		ApplicationContext applicationContext = ApplicationContextFactory.getApplicationContext();
		Message message = applicationContext.getBean("message", Message.class);
		System.out.println(message);

		System.out.println("End");
	}
}
