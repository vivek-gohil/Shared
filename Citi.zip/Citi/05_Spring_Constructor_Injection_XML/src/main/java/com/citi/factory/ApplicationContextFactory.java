package com.citi.factory;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ApplicationContextFactory {
	private static ApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");

	public static ApplicationContext getApplicationContext() {
		return applicationContext;
	}

}
