package com.citi.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.citi.pojo.Message;

public class MessageMain {
	public static void main(String[] args) {
		System.out.println("Start");

		System.out.println("Injecting Message Class Object From Spring Container");
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
		Message message2 = applicationContext.getBean("msg", Message.class);
		System.out.println(message2);
		
		System.out.println("End");
	}
}
