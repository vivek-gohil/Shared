package com.citi.main;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.citi.application.MyApplication;
import com.citi.service.EmailService;
import com.citi.service.MessageService;
import com.citi.service.SMSService;
import com.citi.service.WhatsappService;

public class ApplicationMain {

	public static void main(String[] args) {

//		EmailService emailService = new EmailService();
//		MyApplication application = new MyApplication(emailService);
//		application.processMessage("Hello World!!", "ghl_vivek@hotmail.com");

//		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
//		EmailService emailService = applicationContext.getBean("email", EmailService.class);
//		MyApplication application = new MyApplication(emailService);
//		application.processMessage("Hello World!!", "ghl_vivek@hotmail.com");

//		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
//		MyApplication application = applicationContext.getBean("application", MyApplication.class);
//
//		application.processMessage("Hello World!!", "ghl_vivek@hotmail.com");

		Scanner scanner = new Scanner(System.in);
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
		String continueChoice;
		do {
			System.out.println("1. SMS");
			System.out.println("2. Email");
			System.out.println("3. Whatsapp");
			System.out.println("Enter your choice");
			int choice = scanner.nextInt();

			MyApplication application = getApplication(choice, applicationContext);
			application.processMessage("This is sample message", "Vivek Gohil");
			System.out.println("Do you want to continue?");
			continueChoice = scanner.next();
		} while (continueChoice.equals("yes"));

	}

	public static MyApplication getApplication(int choice, ApplicationContext applicationContext) {

		switch (choice) {
		case 1:
			return applicationContext.getBean("smsApplication", MyApplication.class);
		case 2:
			return applicationContext.getBean("emailApplication", MyApplication.class);
		case 3:
			return applicationContext.getBean("whatsappApplication", MyApplication.class);
		}
		return null;
	}

}
