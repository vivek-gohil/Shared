package com.citi.service;

public class WhatsappService implements MessageService {
	public void sendMessage(String message, String receiver) {
		System.out.println("Whatsapp is sent to :: " + receiver + " with message :: " + message);
	}
}
