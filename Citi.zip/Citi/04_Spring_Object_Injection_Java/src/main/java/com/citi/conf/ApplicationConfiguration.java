package com.citi.conf;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.citi.pojo.Message;

@Configuration
public class ApplicationConfiguration {

	@Bean("msg")
	public Message getMessage() {
		return new Message();
	}
}
