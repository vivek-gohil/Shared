package com.citi.service;

public class SMSService implements MessageService {
	public void sendMessage(String message, String receiver) {
		System.out.println("SMS is sent to :: " + receiver + " with message :: " + message);
	}
}
