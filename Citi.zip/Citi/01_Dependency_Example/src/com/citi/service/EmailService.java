package com.citi.service;

public class EmailService implements MessageService {
	public void sendMessage(String message, String receiver) {
		System.out.println("Mail is sent to :: " + receiver + " with message :: " + message);
	}
}
