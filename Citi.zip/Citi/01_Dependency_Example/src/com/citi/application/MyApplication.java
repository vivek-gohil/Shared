package com.citi.application;

import com.citi.service.MessageService;

public class MyApplication {
	private MessageService messageService;

	public MyApplication(MessageService messageService) {
		this.messageService = messageService;
	}

	public void processMessage(String message, String receiver) {
		this.messageService.sendMessage(message, receiver);
	}
}
