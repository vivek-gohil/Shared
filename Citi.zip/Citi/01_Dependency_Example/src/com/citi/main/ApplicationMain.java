package com.citi.main;

import com.citi.application.MyApplication;
import com.citi.service.EmailService;

public class ApplicationMain {

	public static void main(String[] args) {
		
		EmailService emailService = new EmailService();
		MyApplication application = new MyApplication(emailService);
		application.processMessage("Hello World!!","ghl_vivek@hotmail.com");
		
	}

}
