package com.citi.main;

import java.util.Scanner;

import com.citi.application.MyApplication;
import com.citi.service.EmailService;
import com.citi.service.MessageService;
import com.citi.service.SMSService;
import com.citi.service.WhatsappService;

public class ApplicationMainV2 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		System.out.println("1. SMS");
		System.out.println("2. Email");
		System.out.println("3. Whatsapp");
		System.out.println("Enter your choice");
		int choice = scanner.nextInt();
		MessageService service = getMessageService(choice);

		MyApplication application = new MyApplication(service);
		application.processMessage("This is sample message", "Vivek Gohil");

	}

	public static MessageService getMessageService(int choice) {
		switch (choice) {
		case 1:
			return new SMSService();
		case 2:
			return new EmailService();
		case 3:
			return new WhatsappService();
		}
		return null;
	}

}
