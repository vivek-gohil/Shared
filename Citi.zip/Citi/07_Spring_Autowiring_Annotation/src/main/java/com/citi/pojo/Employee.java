package com.citi.pojo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class Employee {
	private int employeeId;
	private String name;
	private double salary;

	@Autowired
	private Address permanentAddress;

	public Employee() {
		System.out.println("Default Constructor of Employee");
	}

	public Employee(int employeeId, String name, double salary, Address permanentAddress) {
		super();
		this.employeeId = employeeId;
		this.name = name;
		this.salary = salary;
		this.permanentAddress = permanentAddress;
		System.out.println("Param. Constructor of Employee");
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		System.out.println("Setting employeeId :: " + employeeId);
		this.employeeId = employeeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		System.out.println("Setting name :: " + name);
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		System.out.println("Setting salary :: " + salary);
		this.salary = salary;
	}

	public Address getPermanentAddress() {
		return permanentAddress;
	}

	public void setPermanentAddress(Address permanentAddress) {
		System.out.println("Setting permanentAddress :: " + permanentAddress);
		this.permanentAddress = permanentAddress;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", name=" + name + ", salary=" + salary + ", permanentAddress="
				+ permanentAddress + "]";
	}

}
