package com.seclore.main;

import com.seclore.pojo.Account;

public class AccountMainV2 {
	public static void main(String[] args) throws CloneNotSupportedException {
//		Account account = new Account();
//		System.out.println(account);
//
//		Account account2 = new Account(101, "Vivek Gohil", 1000);
//		System.out.println(account2);

		Account account;

		account = new Account(101, "Vivek Gohil", 1000);

		System.out.println(account);

		Account account2 = account;
		System.out.println("Printing account2 ");
		System.out.println(account2);
		System.out.println("Setting balance = 3000");
		account2.setBalance(3000);
		System.out.println("----------------------------");
		System.out.println("Printing account2 :: clone object");
		System.out.println(account2);
		System.out.println(account);

		System.out.println("main end");
	}
}
