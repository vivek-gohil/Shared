package com.seclore.main;

import java.util.Scanner;

import com.seclore.pojo.Employee;

public class ArrayMain {
	public static void main(String[] args) {
//		int[] numbers = { 5, 2, 3, 1, 55, 88, 34, 29 };
		Scanner scanner = new Scanner(System.in);
//
//		for (int i = 0; i < numbers.length; i++) {
//			System.out.println("Enter array element for index " + i);
//			numbers[i] = scanner.nextInt();
//		}
//
//		System.out.println("-----------------------");
//		System.out.println("Data in your array");
//		for (int i : numbers) {
//			System.out.println(i);
//		}

		// Next level
		Employee[] employees = new Employee[5];

		for (int i = 0; i < employees.length; i++) {
			employees[i] = new Employee();
			employees[i].setEmployeeId(i);
			System.out.println("Enter Name");
			employees[i].setName(scanner.nextLine());
			System.out.println("Enter Salary");
			employees[i].setSalary(scanner.nextInt());
			scanner.nextLine();
		}

		System.out.println("---------------------------------");
		for (Employee employee : employees) {
			System.out.println(employee);
		}
		System.out.println("end");

	}
}
