package com.seclore.service;

public interface MessageInterface {
	public void sendMessage(String to, String message);
	
	default void print() {
		System.out.println("Hello World :: Java 8");
	}
}
