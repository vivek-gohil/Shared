package com.seclore.factory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
	private static final String USER;
	private static final String PASSWORD;
	private static final String URL;
	private static final String DRIVER;

	static {
		USER = "sa";
		PASSWORD = "Bahubali@010420";
		URL = "jdbc:sqlserver://localhost:1433;databaseName=TrainingDB;";
		DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	}

	public static Connection getConnection() throws ClassNotFoundException, SQLException {
		Connection connection = null;
		Class.forName(DRIVER);
		connection = DriverManager.getConnection(URL, USER, PASSWORD);
		return connection;
	}
}
