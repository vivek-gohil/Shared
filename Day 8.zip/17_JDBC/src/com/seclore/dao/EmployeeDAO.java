package com.seclore.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.seclore.factory.ConnectionFactory;
import com.seclore.pojo.Employee;

public class EmployeeDAO {
	private Connection connection;
	private PreparedStatement preparedStatement;
	private ResultSet resultSet;
	private int count;
	private String sql;

	public boolean addNewEmployee(Employee employee) {
		try {
			connection = ConnectionFactory.getConnection();

			sql = "insert into employee_master values(?,?,?)";

			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, employee.getEmployeeId());
			preparedStatement.setString(2, employee.getName());
			preparedStatement.setDouble(3, employee.getSalary());

			count = preparedStatement.executeUpdate();

			if (count > 0)
				return true;
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return false;
	}

	public List<Employee> getAllEmployees() {
		List<Employee> employeeList = null;
		try {
			connection = ConnectionFactory.getConnection();
			employeeList = new ArrayList<Employee>();
			sql = "select * from employee_master";
			preparedStatement = connection.prepareStatement(sql);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				Employee employee = new Employee();
				employee.setEmployeeId(resultSet.getInt("employee_id"));
				employee.setName(resultSet.getString("name"));
				employee.setSalary(resultSet.getDouble("salary"));
				employeeList.add(employee);
			}

		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return employeeList;
	}

	public boolean updateEmployee(Employee employee) {
		try {
			connection = ConnectionFactory.getConnection();
			sql = "update employee_master set name=? , salary=? where employee_id=?";
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, employee.getName());
			preparedStatement.setDouble(2, employee.getSalary());
			preparedStatement.setInt(3, employee.getEmployeeId());

			count = preparedStatement.executeUpdate();
			if (count > 0)
				return true;
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return false;
	}

	public boolean deleteByEmployeeId(int employeeId) {
		try {
			connection = ConnectionFactory.getConnection();
			sql = "delete employee_master where employee_id=?";
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, employeeId);

			count = preparedStatement.executeUpdate();
			if (count > 0)
				return true;
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return false;
	}

	public Employee getEmmployeeByEmployeeId(int employeeId) {
		try {
			connection = ConnectionFactory.getConnection();
			sql = "select * from employee_master where employee_Id = ?";
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, employeeId);
			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				Employee employee = new Employee();
				employee.setEmployeeId(resultSet.getInt("employee_id"));
				employee.setName(resultSet.getString("name"));
				employee.setSalary(resultSet.getDouble("salary"));
				return employee;
			}

		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return null;
	}

}
