package com.seclore.main;

import java.sql.Connection;
import java.sql.SQLException;

import com.seclore.factory.ConnectionFactory;

public class DBConnectionTestingMain {
	public static void main(String[] args) {
		Connection connection = null;
		try {
			connection = ConnectionFactory.getConnection();
			System.out.println("Connection Success");
		} catch (ClassNotFoundException e) {
			System.out.println("Driver Not Found");
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			System.out.println("Failed To Connect Database Server");
			System.out.println(e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Failed To Close Database Connection");
				System.out.println(e.getMessage());
			}
		}

	}
}
