package com.seclore.main;

import java.util.List;
import java.util.Scanner;

import com.seclore.dao.EmployeeDAO;
import com.seclore.pojo.Employee;

public class EmployeeJDBCMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		EmployeeDAO employeeDAO = new EmployeeDAO();

		int employeeId;
		String name;
		double salary;
		int choice;
		String continueChoice;
		List<Employee> employeeList;

		do {
			System.out.println("Menu");
			System.out.println("1. Add New Employee");
			System.out.println("2. Prit All Employees");
			System.out.println("3. Update Employee Name and Salary");
			System.out.println("4. Delete Employee by employeeId");
			System.out.println("5. Print Single Employee");
			System.out.println("Enter your choice");
			choice = scanner.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Enter EmployeeId");
				employeeId = scanner.nextInt();
				scanner.nextLine();
				System.out.println("Enter Name");
				name = scanner.nextLine();
				System.out.println("Enter Salary");
				salary = scanner.nextDouble();

				Employee employee = new Employee(employeeId, name, salary);
				if (employeeDAO.addNewEmployee(employee))
					System.out.println("New employee added successfully!");
				else
					System.out.println("Failed to add employee");
				break;
			case 2:
				employeeList = employeeDAO.getAllEmployees();
				for (Employee emp : employeeList) {
					System.out.println(emp);
				}
				break;
			case 3:
				System.out.println("Enter existing EmployeeId");
				employeeId = scanner.nextInt();
				scanner.nextLine();
				System.out.println("Enter New Name");
				name = scanner.nextLine();
				System.out.println("Enter New Salary");
				salary = scanner.nextDouble();

				employee = new Employee(employeeId, name, salary);
				if (employeeDAO.updateEmployee(employee))
					System.out.println(" employee details updated successfully!");
				else
					System.out.println("Failed to update employee details");
				break;
			case 4:
				System.out.println("Enter existing EmployeeId");
				employeeId = scanner.nextInt();
				if (employeeDAO.deleteByEmployeeId(employeeId))
					System.out.println(" employee deleted successfully!");
				else
					System.out.println("Failed to deleted employee");
				break;
			case 5:
				System.out.println("Enter existing EmployeeId");
				employeeId = scanner.nextInt();
				employee = employeeDAO.getEmmployeeByEmployeeId(employeeId);
				if (employee != null)
					System.out.println(employee);
				else
					System.out.println("Employee not found!");
				break;
			default:
				System.out.println("Invalid Choice");
				break;
			}
			System.out.println("Do you want to continue");
			continueChoice = scanner.next();
		} while (continueChoice.equals("yes"));

	}

}
