package com.seclore.main;

import com.seclore.test.MyClass;

public class MyClassMainV2 {
	public static void main(String[] args) throws ClassNotFoundException, InterruptedException {
		System.out.println("start");
		// MyClass obj = new MyClass();
		// MyClass.display();

		Class.forName("com.seclore.test.MyClass");

		for (int i = 0; i < 10; i++) {
			Thread.sleep(1000);
			System.out.print(".");
		}
		
		System.out.println("Loading Same class again");
		System.out.println("Loading start");
		Class.forName("com.seclore.test.MyClass");
		System.out.println("Loading end");
		System.out.println("End");
	}
}
