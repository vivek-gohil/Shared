package com.seclore.test;

import java.beans.Transient;

public class MyClass {

	private transient static int num1;
	private static int num2 = 10;

	public MyClass() {
		System.out.println("Default constructor of MyClass");
	}

	{
		System.out.println("non static block");
	}

	static {
		System.out.println("static block");
		num1 = 10;
	}

	public static void display() {
		System.out.println(num1);
		System.out.println(num2);
		num1++;
		num2++;
		System.out.println(num1);
		System.out.println(num2);
	}
}
