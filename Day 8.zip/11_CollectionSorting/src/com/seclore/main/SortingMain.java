package com.seclore.main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.seclore.pojo.Fruit;

public class SortingMain {
	public static void main(String[] args) {
//		String[] fruits = new String[] { "Pineapple", "Apple", "Orange", "Banana" };
//
//		Arrays.sort(fruits);
//
//		for (String temp : fruits) {
//			System.out.println(temp);
//		}

//		List<String> fruits = new ArrayList<String>();
//		fruits.add("Pineapple");
//		fruits.add("Apple");
//		fruits.add("Orange");
//		fruits.add("Banana");
//
//		// Collections.sort(fruits);
//		Collections.sort(fruits, Collections.reverseOrder());
//		
//		System.out.println(fruits);

		Fruit[] fruits = new Fruit[4];

		Fruit pineapple = new Fruit("Pineapple", "Pineapple description", 70);
		Fruit apple = new Fruit("Apple", "Apple Description", 100);
		Fruit orange = new Fruit("Orange", "Orange description", 80);
		Fruit banana = new Fruit("Banana", "Banana description", 90);

		fruits[0] = pineapple;
		fruits[1] = apple;
		fruits[2] = orange;
		fruits[3] = banana;

		Arrays.sort(fruits);

		for (Fruit fruit : fruits) {
			System.out.println(fruit);
		}

	}
}
