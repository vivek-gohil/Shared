package com.seclore.main;

import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import com.seclore.annotations.JavaFileInfo;
import com.seclore.pojo.DemoClass;

public class ProcessAnnotationMain {
	public static void main(String[] args) {
		Class<DemoClass> demoClass = DemoClass.class;
		readAnnotation(demoClass);

		System.out.println();

		try {
			Method method = demoClass.getMethod("printMessage", new Class[] {});
			readAnnotation(method);
		} catch (NoSuchMethodException | SecurityException e) {
			e.printStackTrace();
		}

//		Method[] methods = demoClass.getMethods();
//		for (Method method : methods) {
//			System.out.println(method.getName());
//			readAnnotation(method);
//		}

	}

	public static void readAnnotation(AnnotatedElement annotatedElement) {
		System.out.println("Finding annotations on " + annotatedElement.getClass().getName());
		Annotation[] annotations = annotatedElement.getAnnotations();
		for (Annotation annotation : annotations) {
			if (annotation instanceof JavaFileInfo) {
				JavaFileInfo fileInfo = (JavaFileInfo) annotation;
				System.out.println("Author :: " + fileInfo.author());
				System.out.println("Version :: " + fileInfo.version());
			}
		}
	}
}
