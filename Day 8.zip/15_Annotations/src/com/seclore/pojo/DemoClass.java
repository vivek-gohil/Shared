package com.seclore.pojo;

import com.seclore.annotations.JavaFileInfo;

//@PrecreateObject(count = "10")


@JavaFileInfo
public class DemoClass {

	private String message = "This is sample message";

	@JavaFileInfo(author = "Vivek Gohil", version = "1.0")
	public String printMessage() {
		return message;
	}
}
