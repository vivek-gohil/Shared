package com.seclore.main;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class HelloWorldLoggerMain {

	private static final Logger LOGGER = LogManager.getLogger(HelloWorldLoggerMain.class);

	public static void main(String[] args) {
		for (int i = 0; i < 10000; i++) {
			LOGGER.info("This is info");
			LOGGER.debug("This is debug");
			LOGGER.warn("this is warng");
			LOGGER.error("This is error");
			LOGGER.fatal("this is fatal");
			LOGGER.trace("this is trace");
		}
	}
}
