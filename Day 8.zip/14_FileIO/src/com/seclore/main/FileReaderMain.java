package com.seclore.main;

import java.io.File;
import java.util.Scanner;

import com.seclore.util.FileReaderUtil;

public class FileReaderMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		FileReaderUtil fileReaderUtil = new FileReaderUtil();

		File file;
		String path;
		char[] data;

		System.out.println("Please enter path to read file");
		path = scanner.next();
		file = new File(path);
		data = fileReaderUtil.readFile(file);

		for (char c : data) {
			System.out.print(c);
		}
		scanner.close();

	}
}
