package com.seclore.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

import com.seclore.exceptions.InvalidProductPriceException;
import com.seclore.pojo.Product;

public class Calculator {
	int num1 = 0, num2 = 0, result;

	public void acceptNumber() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Number1");
		num1 = scanner.nextInt();
		System.out.println("Enter Number2");
		num2 = scanner.nextInt();
	}

	public void calculateResult() {
		try {
		System.out.println("Calculating Result..");
		result = num1 / num2;
		} catch (ArithmeticException e) {
			System.out.println("Oops Something went wrong!");
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			System.out.println("Thank you");
		}
	}

	public void displayResult() {
		System.out.println("Result is = " + result);
	}
}
