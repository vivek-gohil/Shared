package com.seclore.pojo;

public class MyClass {

	//private <T> myVariable;

	public <T> void print(T myVariable) {
		//this.myVariable = myVariable;
		System.out.println(myVariable);
	}

	public void add(T value) {

	}
}
