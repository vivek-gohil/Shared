package com.seclore.main;

import com.seclore.pojo.Employee;
import com.seclore.pojo.MyClass;

public class GenerricMain {
	public static void main(String[] args) {
		MyClass<String> myClassString = new MyClass<String>();
		myClassString.print("Hello");

		MyClass<Integer> myClassInt = new MyClass<Integer>();
		myClassInt.print(10);

		MyClass<Boolean> myClassBoolean = new MyClass<Boolean>();
		myClassBoolean.print(true);

		Employee employee = new Employee(1, "Test", 101);
		MyClass<Employee> myClassEmployee = new MyClass<Employee>();
		myClassEmployee.print(employee);

		myClassEmployee.add(employee);

	}
}
