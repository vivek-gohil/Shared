package com.seclore.main;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.seclore.pojo.Employee;

public class HashMapMain {
	public static void main(String[] args) {
//		Map employeeMap;

//		employeeMap = new HashMap<Integer, Employee>();
//
//		employeeMap = new HashMap<String, String>();

		Map<Integer, Employee> employeeMap;

		employeeMap = new HashMap<Integer, Employee>();

		employeeMap.put(Integer.valueOf(1), new Employee(101, "Vivek", 1000));
		employeeMap.put(Integer.valueOf(3), new Employee(103, "Vinayak", 1000));
		employeeMap.put(null, new Employee(0, "", 0));

		System.out.println(employeeMap);

		employeeMap.getOrDefault(4, new Employee(0, "", 0));
		
		System.out.println("--------------------------------------");
		Set<Integer> employeesKey = employeeMap.keySet();
		for (Integer key : employeesKey) {
			System.out.println(key);
			System.out.println(employeeMap.get(key));
		}

		System.out.println("--------------------------------------");
		Collection<Employee> emp = employeeMap.values();
		for (Employee value : emp) {
			System.out.println(value);
		}

	}
}
