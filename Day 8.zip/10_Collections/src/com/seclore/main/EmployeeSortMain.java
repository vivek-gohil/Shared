package com.seclore.main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.seclore.pojo.Employee;
import com.seclore.util.EmployeeIdComparator;
import com.seclore.util.EmployeeNameCompartor;

public class EmployeeSortMain {

	public static void main(String[] args) {
		Employee employee1 = new Employee(100, "Vivek", 1000);
		Employee employee2 = new Employee(199, "Reema", 1000);
		Employee employee3 = new Employee(101, "Seema", 1000);

		List<Employee> employees = new ArrayList<Employee>();

		employees.add(employee1);
		employees.add(employee2);
		employees.add(employee3);

		// Collections.sort(employees, new EmployeeIdComparator());

		// Collections.sort(employees, new EmployeeNameCompartor());
		// Collections.sort(employees, (e1, e2) ->
		// e1.getName().compareTo(e2.getName()));
		Collections.sort(employees, (e1, e2) -> (int) e1.getSalary() - (int) e2.getSalary());
		System.out.println(employees);

	}

}
