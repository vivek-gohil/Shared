package com.seclore.main;

import com.seclore.pojo.Current;

public class AccountMainV5 {
	public static void main(String[] args) {
		Current current = new Current(101, "Vivek Gohil", 10000, 50000);

		System.out.println(current);
		
		System.out.println("withdraw :: 5000");
		current.withdraw(5000);
		System.out.println("Main Balance :: " + current.getBalance()); //5000
		System.out.println("Overdraft Balance :: " + current.getOverdraftBalance()); //50000
		System.out.println("-----------------------------------------------");
		System.out.println("withdraw :: 10000");
		current.withdraw(10000);
		System.out.println("Main Balance :: " + current.getBalance()); // 0
		System.out.println("Overdraft Balance :: " + current.getOverdraftBalance()); //45000
		System.out.println("-----------------------------------------------");
		System.out.println("deposit :: 2000");
		current.deposit(2000);
		System.out.println("Main Balance :: " + current.getBalance()); // 0
		System.out.println("Overdraft Balance :: " + current.getOverdraftBalance()); //47000
		System.out.println("-----------------------------------------------");
		current.deposit(25000);
		System.out.println("Main Balance :: " + current.getBalance()); // 22000
		System.out.println("Overdraft Balance :: " + current.getOverdraftBalance()); //50000
		System.out.println("-----------------------------------------------");
		
		
		
		
		
		
	}
}
