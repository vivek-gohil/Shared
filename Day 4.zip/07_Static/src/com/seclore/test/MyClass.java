package com.seclore.test;

public class MyClass {
	private static int num1 = 10;
	private static int num2 = 10;

	public MyClass() {
		System.out.println("Default constructor of MyClass");
	}

	{
		System.out.println("non static block");
	}

	static {
		System.out.println("static block");
	}

	public static void display() {
		System.out.println(num1);
		System.out.println(num2);
		num1++;
		num2++;
		System.out.println(num1);
		System.out.println(num2);
	}
}
