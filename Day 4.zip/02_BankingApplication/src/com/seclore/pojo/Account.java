package com.seclore.pojo;

public abstract class Account extends Object {
	// instance level variables
	private int accountNumber;
	private String name;
	private double balance;

	// ctrl+<space>
	public Account() {
		System.out.println("Default Constructor of Account");
	}

	// alt+shift+s o
	public Account(int accountNumber, String name, double balance) {
		super();
		this.accountNumber = accountNumber;
		this.name = name;
		this.balance = balance;
		System.out.println("Param. constructor of Account");
	}

	public abstract boolean withdraw(double amount);

	public abstract boolean deposit(double amount); 

	// alt+shift+s r
	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	// alt+shift+s s
	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", name=" + name + ", balance=" + balance + "]";
	}

}
