package com.seclore.main;

import com.seclore.pojo.Account;

public class AccountMain {

	public static void main(String[] args) {
		Account account = new Account();

		// account.accountNumber = 101;
		account.setAccountNumber(101);
		account.setName("Vivek Gohil");
		account.setBalance(1000);

		System.out.println("AccountNumber :: " + account.getAccountNumber());
		System.out.println("Name :: " + account.getName());
		System.out.println("Balance :: " + account.getBalance());

		// System.out.println(account);
		System.out.println(account.toString());

		System.out.println("Main end");
	}

}
