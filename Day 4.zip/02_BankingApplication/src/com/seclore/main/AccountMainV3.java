package com.seclore.main;

import java.util.Scanner;

import com.seclore.pojo.Account;

public class AccountMainV3 {
	public static void main(String[] args) {

		int accountNumber;
		String name;
		double balance;
		int choice;
		double amount;
		String continueChoice;

		Account account;
		Scanner scanner = new Scanner(System.in);

		System.out.println("Enter Account Details");
		System.out.println("Enter AccountNumber");
		accountNumber = scanner.nextInt();

		scanner.nextLine();

		System.out.println("Enter Name");
		name = scanner.nextLine();
//		System.out.println("Enter Balance");
//		balance = scanner.nextDouble();

		account = new Account(accountNumber, name, 0);
		do {
			System.out.println("Account Details");
			System.out.println(account);

			System.out.println("Menu");
			System.out.println("1. Get Account Balance");
			System.out.println("2.Withdraw");
			System.out.println("3.Deposit");

			System.out.println("Enter your choice");
			choice = scanner.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Balance :: " + account.getBalance());
				break;
			case 2:
				System.out.println("Enter amount to withdraw");
				amount = scanner.nextDouble();
				System.out.println(account.withdraw(amount) ? "Transaction Success" : "Transaction Failed");
				System.out.println("Balance :: " + account.getBalance());
				break;
			case 3:
				System.out.println("Enter amount to deposit");
				amount = scanner.nextDouble();

				System.out.println(account.deposit(amount) ? "Transaction Success" : "Transaction Failed");
				System.out.println("Balance :: " + account.getBalance());
				break;
			default:
				System.out.println("Invalid choice");
				break;
			}
			System.out.println("Do you want to continue?");
			continueChoice = scanner.next();
		} while (continueChoice.equalsIgnoreCase("yes"));

	}
}
