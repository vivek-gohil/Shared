package com.seclore.main;

import com.seclore.pojo.Employee;
import com.seclore.util.EmployeeUtil;

public class EmployeeMain {
	public static void main(String[] args) throws CloneNotSupportedException {
		System.out.println("main start");
		Employee employee = new Employee(101, "Jayant Kulkarni", 1000);

		EmployeeUtil employeeUtil = new EmployeeUtil();

		System.out.println(employee);
		employeeUtil.changeEmployee(employee);
		System.out.println(employee);

		System.out.println("main end");
	}
}
