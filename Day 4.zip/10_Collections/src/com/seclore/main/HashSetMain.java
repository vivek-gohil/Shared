package com.seclore.main;

import java.util.HashSet;
import java.util.Set;

import com.seclore.dao.EmployeeHashSetDAO;
import com.seclore.pojo.Employee;

public class HashSetMain {
	public static void main(String[] args) {
		Employee employee = new Employee(101, "Vivek", 1000);
		System.out.println(employee);
		System.out.println(employee.hashCode());
		System.out.println("----------------------------------------");
		Employee employee2 = new Employee(102, "Divya", 2000);
		System.out.println(employee2);
		System.out.println(employee2.hashCode());
		System.out.println("----------------------------------------");
		Employee employee3 = new Employee(101, "Vivek", 1000);
		System.out.println(employee3);
		System.out.println(employee3.hashCode());
		System.out.println("----------------------------------------");

		EmployeeHashSetDAO dao = new EmployeeHashSetDAO(new HashSet<Employee>());

		System.out.println("Adding Employees into HashSet");
		dao.addNewEmployee(employee);
		dao.addNewEmployee(employee2);
		dao.addNewEmployee(employee3);
		dao.addNewEmployee(null);

		
		
		System.out.println("Retriving Employees from HashSet");
		Set<Employee> employeeSet = dao.getAllEmployees();

		employee.setSalary(3000);
		
		for (Employee emp : employeeSet) {
			System.out.println(emp);
		}
		
		
		
	}
}
