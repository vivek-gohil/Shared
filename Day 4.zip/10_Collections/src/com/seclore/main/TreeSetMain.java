package com.seclore.main;

import java.util.Set;
import java.util.TreeSet;

public class TreeSetMain {
	public static void main(String[] args) {
		Set<String> nameSet = new TreeSet<String>();

		nameSet.add("Z");
		nameSet.add("B");
		nameSet.add("X");
		nameSet.add("A");

		System.out.println(nameSet);
	}
}
