package com.seclore.dao;

import java.util.List;

import com.seclore.pojo.Employee;

public class EmployeeDAO {
	private List<Employee> employeeList;
	

	public EmployeeDAO(List<Employee> employeeList) {
		this.employeeList = employeeList;
	}

	public void addNewEmployee(Employee employee) {
		employeeList.add(employee);
	}

	public List<Employee> getAllEmployees() {
		return employeeList;
	}

	//update name || salary
	//delete employee
	//get single employeeId
}
