package com.seclore.dao;

import java.util.List;
import java.util.Set;

import com.seclore.pojo.Employee;

public class EmployeeHashSetDAO {
	private Set<Employee> employeeSet;

	public EmployeeHashSetDAO(Set<Employee> employeeSet) {
		super();
		this.employeeSet = employeeSet;
	}

	public void addNewEmployee(Employee employee) {
		employeeSet.add(employee);
	}

	public Set<Employee> getAllEmployees() {
		return employeeSet;
	}
	
	//update name || salary
	//delete employee
	//get single employeeId
}
