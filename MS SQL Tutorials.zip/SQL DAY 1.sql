select @@VERSION;

CREATE DATABASE BikeStores;

USE BIKESTORES;

--SELECT QUERY ON DATABASE
select * from [production].[brands];
select * from [production].[categories];
select * from [production].[products];
select * from [production].[stocks];
select * from [sales].[customers]
select * from [sales].[order_items]
select * from [sales].[orders]
select * from [sales].[staffs]
select * from [sales].[stores]

--Section 1 . Querying data
--Basic SQL Server Select statement

--The following query finds the first name and last name of all customers
SELECT 
	first_name,
	last_name
FROM
	sales.customers;

--The following query finds the first name , last name , email of all customers
SELECT 
	first_name,
	last_name,
	email
FROM
	sales.customers;

--The following query finds the first name , last name , email , state of all customers

SELECT 
	first_name,
	last_name,
	email,
	[state]
FROM
	sales.customers;

--Using WHERE clause
--The following query finds the customers who lives in CA
SELECT 
	first_name,
	last_name,
	email,
	[state]
FROM
	sales.customers
WHERE
	state = 'CA';

--Using Sort
--Sort the result using ORDER BY clause
--Sorting Customers by first name
SELECT 
	first_name CUSTOMER_FIRST_NAME,
	last_name,
	email,
	[state]
FROM
	sales.customers
WHERE
	state = 'CA'
ORDER BY
	first_name;

--Using COUNT function
--Print count of customers lives in state CA
SELECT 
	COUNT(first_name)
FROM
	sales.customers
WHERE
	state = 'CA';

SELECT 
	first_name CUSTOMER_FIRST_NAME,
	last_name,
	email,
	city,
	[state]
FROM
	sales.customers
WHERE
	state = 'CA'
ORDER BY
	first_name;



SELECT 
	city,
	COUNT(city) COUNT_CITY
FROM
	sales.customers
WHERE
	state = 'CA'

--Group By
SELECT 
	city,
	COUNT(city) COUNT_CITY
FROM
	sales.customers
WHERE
	state = 'CA'
GROUP BY
	city
ORDER BY
	COUNT(city) DESC

--Print the customers city having more than 5 customers
SELECT 
	city,
	COUNT(city) COUNT_CITY
FROM
	sales.customers
WHERE
	state = 'CA'
GROUP BY
	city
HAVING
	COUNT(city) > 5
ORDER BY
	COUNT(city) DESC

--ORDER OF QUERY EXECUTION
--FROM
--WHERE
--GROUP BY
--HAVING
--SELECT
--ORDER BY
--LIMIT
	
--Section 2. Sorting Data
--SQL Server ORDER BY in detail
SELECT 
	first_name,
	last_name
FROM
	sales.customers
ORDER BY
	first_name;

--sorts the customer list by the first name in descending order.
SELECT 
	first_name,
	last_name
FROM
	sales.customers
ORDER BY
	first_name DESC;

--Sort a result set by multiple columns
SELECT 
	city,
	first_name,
	last_name
FROM
	sales.customers
ORDER BY
	city

----It sorts the customer list by the city first and then by the first name
SELECT 
	city,
	first_name,
	last_name
FROM
	sales.customers
ORDER BY
	city,
	first_name

--Sort a result set by multiple columns and different orders
--The following statement sorts the customers by the city in descending order 
--and the sort the sorted result set by the first name in ascending order.
SELECT 
	city,
	first_name,
	last_name
FROM
	sales.customers
ORDER BY
	city DESC,
	first_name 

----Sort a result set by a column that is not in the select list
SELECT 
	city,
	first_name,
	last_name
	--state
FROM
	sales.customers
ORDER BY
	state

SELECT LEN('Vivek');

SELECT 
	first_name ,
	LEN(first_name) first_name_length
FROM
	sales.customers;

--Sort a result set by an expression
--The following statement uses the LEN() function in the ORDER BY clause to 
--retrieve a customer list sorted by the length of the first name.
SELECT 
	first_name ,
	LEN(first_name) first_name_length
FROM
	sales.customers
ORDER BY
	LEN(first_name) DESC;

--Sort by ordinal positions of columns
SELECT 
	first_name,
	last_name
FROM
	sales.customers
ORDER BY
	1 ASC,
	2 DESC;


--Section 3. Limiting rows
--OFFSET and FETCH
SELECT * FROM [production].[products];

--OFFSET
--Skip fisrt 10 products and print the rest
SELECT 
	[product_name],
	[list_price]
FROM
	[production].[products]
ORDER BY
	[list_price]
OFFSET 10 ROWS;


--skip the first 10 products and select the next 10 products


SELECT 
	[product_name],
	[list_price]
FROM
	[production].[products]
ORDER BY
	[list_price]
OFFSET 10 ROWS
FETCH NEXT 10 ROWS ONLY;

--To get the top 10 most expensive products

SELECT 
	[product_name],
	[list_price]
FROM
	[production].[products]
ORDER BY
	[list_price]
OFFSET 0 ROWS
FETCH FIRST 10 ROWS ONLY;

--SQL Server SELECT TOP
--To get the top 10 most expensive products
--ORDER BY is optional
SELECT TOP 10
	[product_name],
	[list_price]
FROM
	[production].[products]	
ORDER BY
	[list_price]

--Using percentage of rows
SELECT TOP 1 PERCENT
	[product_name],
	[list_price]
FROM
	[production].[products]	
ORDER BY
	[list_price]

--check 
SELECT TOP 3 WITH TIES
    product_name, 
    list_price
FROM
    production.products
ORDER BY 
    list_price DESC;

--Section 4 
--DISTINCT
SELECT 
	city 
FROM 
	[sales].[customers]
ORDER BY
	city;

SELECT 
	DISTINCT city 
FROM 
	[sales].[customers]
ORDER BY
	city;


--DISTINCT multiple columns
SELECT DISTINCT
	city,
	state
FROM
	sales.customers
ORDER BY
	city,
	state

--SQL WHERE 
SELECT 
	* 
FROM
	[production].[products]

--The following statement retrieves all products with the category id 1:
SELECT 
	* 
FROM
	[production].[products]
WHERE
	category_id = 1
ORDER BY
	list_price desc;

--FINDING ROWS THAT MEET TWO CONDITION
--two conditions: category id is 1 and the model is 2018.
SELECT 
	* 
FROM
	[production].[products]
WHERE
	category_id = 1
AND
	model_year = 2017
ORDER BY
	list_price desc;

--find the products whose list price is greater than 300 and model is 2018.
SELECT 
	* 
FROM
	[production].[products]
WHERE
	list_price > 300
AND
	model_year = 2018
ORDER BY
	list_price desc;

--find products whose list price is greater than 3,000 or model is 2018.
SELECT 
	* 
FROM
	[production].[products]
WHERE
	list_price > 3000
OR
	model_year = 2018
ORDER BY
	list_price desc;


--finds the products whose list prices are between 1,899 and 1,999.99:
SELECT 
	* 
FROM
	[production].[products]
WHERE
	list_price >= 1899
AND
	list_price <= 1999.99
ORDER BY
	list_price desc;

SELECT 
	* 
FROM
	[production].[products]
WHERE
	list_price BETWEEN 1899.00 AND 1999.99
ORDER BY
	list_price desc;

--IN
--find products whose list price is 299.99 or 466.99 or 489.99.
SELECT 
	* 
FROM
	[production].[products]
WHERE
	list_price = 299.99
OR
	list_price = 466.99
OR
	list_price = 489.99

SELECT 
	* 
FROM
	[production].[products]
WHERE
	list_price IN( 299.99 , 466.99 , 489.99);

SELECT 
	*
FROM
	[production].[stocks]
where 
	store_id =1 
AND 
	quantity >= 30

SELECT 
	*
FROM
	[production].[products]

--a list of product identification numbers of the products located in 
--the store id one and has the quantity greater than or equal to 30:

SELECT 
	product_id,
	product_name,
	list_price
FROM
	[production].[products]
where
	product_id IN (
SELECT 
	product_id
FROM
	[production].[stocks]
where 
	store_id =1 
AND 
	quantity >= 30)



SELECT * FROM [sales].[customers]
WHERE CUSTOMER_ID IN (
SELECT 
	customer_id
FROM
	[sales].[orders]
WHERE
	order_status = 1
);


--LIKE
SELECT 
	* 
FROM
	[production].[products];

-- find products whose name contains the string 'Cruiser'
SELECT 
	* 
FROM
	[production].[products]
WHERE
	product_name LIKE '%Cruiser%';

SELECT 
	* 
FROM
	[production].[products]
WHERE
	product_name LIKE '%2017';

--Column alias
SELECT 
	first_name FIRSTNAME,
	last_name LASTNAME
FROM
[sales].[customers]
ORDER BY
	FIRSTNAME DESC;

--Get full names of customers - concatenate the first name and last name using + operator
SELECT 
	first_name + ' ' + last_name 'CUSTOMERS FULL NAME'
FROM
[sales].[customers];



SELECT
	first_name + ' ' + last_name as 'CUSTOMERS FULL NAME',
	COUNT(first_name + ' ' + last_name )
FROM
	[sales].[customers]
GROUP BY
	first_name + ' ' + last_name 
HAVING 
	COUNT(first_name + ' ' + last_name ) > 1
ORDER BY  
	COUNT(first_name + ' ' + last_name ) DESC


--Table Aliases

SELECT
	c.first_name
FROM
	[sales].[customers] c;

--Section 5 Joining Tables
CREATE SCHEMA hr;
DROP TABLE hr.candidates;
CREATE TABLE hr.candidates(
	id int,
	full_name varchar(30)
);

DROP TABLE hr.employee;
CREATE TABLE hr.employee(
	id int,
	full_name varchar(30),
	salary int
);

INSERT INTO hr.candidates(id , full_name)
VALUES
	(1,'Vivek Gohil'),
	(2,'Rekha Sarode'),
	(3,'Ashwinkumar Suthar'),
	(4,'Aquin Rodrigues');

INSERT INTO hr.employee(id , full_name , salary)
VALUES
	(1,'Trupti Acharekar',100),
	(2,'Samarth Patil',200),
	(3,'Ashwinkumar Suthar',300),
	(4,'Aquin Rodrigues',400);


SELECT * FROM hr.candidates;
SELECT * FROM hr.employee;

--cross join
SELECT 
	*
FROM
	hr.candidates 
CROSS JOIN
	hr.employee


--inner join
SELECT 
	*
FROM
	hr.candidates c
INNER JOIN
	hr.employee e
ON
	c.full_name = e.full_name;

SELECT 
	c.id candidate_id,
	e.id employee_id,
	c.full_name candidate_name,
	e.full_name employee_name
FROM
	hr.candidates c INNER JOIN hr.employee e
ON
	 e.full_name = c.full_name ;

--LEFT JOIN
SELECT 
	c.id candidate_id,
	c.full_name candidate_name,
	e.id employee_id,
	e.full_name employee_name
FROM
	hr.candidates c LEFT JOIN hr.employee e
ON
	c.full_name = e.full_name;

--RIGH JOIN
SELECT 
	c.id candidate_id,
	c.full_name candidate_name,
	e.id employee_id,
	e.full_name employee_name
FROM
	hr.candidates c RIGHT JOIN hr.employee e
ON
	c.full_name = e.full_name;

--FULL JOIN
SELECT 
	c.id candidate_id,
	c.full_name candidate_name,
	e.id employee_id,
	e.full_name employee_name
FROM
	hr.candidates c FULL JOIN hr.employee e
ON
	c.full_name = e.full_name;

--alias - How to create copy using alias

SELECT 
	*
FROM
	hr.candidates c1
INNER JOIN
	hr.candidates c2
ON
	c1.full_name = c2.full_name;

--Self join
SELECT 
	--mgr.first_name mgr_name,
	--emp.first_name emp_name
	 mgr.first_name  + ' Reports to ' + emp.first_name manager_details
FROM
	[sales].[staffs] emp
INNER JOIN
	[sales].[staffs] mgr
	
ON 
	  emp.staff_id = mgr.manager_id;

--Version V2
SELECT 
	emp.first_name + ' ' + emp.last_name employee,
	mgr.first_name + ' ' + mgr.last_name manager
FROM
	[sales].[staffs] emp
INNER JOIN
	[sales].[staffs] mgr
ON
	mgr.staff_id = emp.manager_id

--DATA DEFINATION
--CREATE NEW DATABASE
CREATE DATABASE TestDB;	

--This statement lists all database in the SQL Server.
SELECT
	*
FROM
	master.sys.databases;

EXEC sp_databases;

--DROP DATABASE
DROP DATABASE TestDB;
DROP DATABASE IF EXISTS TestDB;

--CREATE SCHEMA
CREATE SCHEMA customer_services;
GO

CREATE TABLE customer_services.employee_new(
	id int,
	full_name varchar(30),
	salary int
);


--DROP SCHEMA
DROP SCHEMA customer_services;
DROP TABLE customer_services.employee_new;

--CREATE TABLE AND IDENTITY EXAMPLE
DROP TABLE hr.person;
CREATE TABLE hr.person(
	person_id int IDENTITY(100,10),
	first_name varchar(20),
	last_name varchar(30),
	gender char(1)
);

--INSERT
INSERT INTO hr.person(first_name,last_name,gender)
values('Vivek','Gohil' , 'M');
INSERT INTO hr.person(first_name,last_name,gender)
values('Aquin','ROdrigues' , 'M');
INSERT INTO hr.person(first_name,last_name,gender)
values('Ashwinkumar','Suthar' , 'M');
INSERT INTO hr.person(first_name,last_name,gender)
values('Rekha','Sasrode' , 'F');

SELECT
	*
FROM
	hr.person;

--CREATE SQUENCE
CREATE SEQUENCE hr.person_id_sequence
AS INT
START WITH 1
INCREMENT BY 1;


SELECT NEXT VALUE FOR hr.person_id_sequence;

CREATE TABLE hr.person(
	person_id int,
	first_name varchar(20),
	last_name varchar(30),
	gender char(1)
);


INSERT INTO hr.person(person_id ,first_name,last_name,gender)
values(NEXT VALUE FOR hr.person_id_sequence ,'Vivek','Gohil' , 'M');
INSERT INTO hr.person(person_id ,first_name,last_name,gender)
values(NEXT VALUE FOR hr.person_id_sequence ,'Aquin','ROdrigues' , 'M');
INSERT INTO hr.person(person_id ,first_name,last_name,gender)
values(NEXT VALUE FOR hr.person_id_sequence ,'Ashwinkumar','Suthar' , 'M');
INSERT INTO hr.person(person_id ,first_name,last_name,gender)
values(NEXT VALUE FOR hr.person_id_sequence ,'Rekha','Sasrode' , 'F');

SELECT 
	*
FROM 
	hr.person_details;

DROP TABLE IF EXISTS hr.person;

--DELETE operation
DELETE hr.person_details;

TRUNCATE TABLE hr.person;

--Use less transaction logs
--Reset the identity

begin transaction
--query 1
--5sec
--some condition
rollback transaction
save transaction
commit
end transaction

EXEC sp_rename 'hr.person' , 'person_details';

--ALTER
--ALTER TABLE ADD COLUMN
SELECT 
	*
FROM 
	hr.person_details;

ALTER TABLE hr.person
ADD qualification VARCHAR(244);

UPDATE hr.person_details
set qualification = 'Graduate' 
where person_id = 100;

UPDATE hr.person_details
set qualification = 'Graduate' 
where person_id > 100;

ALTER TABLE hr.person_details
DROP COLUMN qualification;

UPDATE hr.person_details
SET qualification = NULL
WHERE person_id = 120;

DELETE FROM hr.person_details
where person_id = 100;

select * from hr.person;

ALTER TABLE hr.person
ALTER COLUMN qualification VARCHAR(20);

--DDL
	--CREATE
	--ALTER
	--DROP
--DML
	--INSERT
	--UPDATE
	--DELETE

--CONSTRAINTS - RULES ON COLUMNS 
--PRIMARY KEY 
--FOREIGN KEY
--NOT NULL
--CHECK 

DROP TABLE sales.activities;
CREATE TABLE sales.activities(
	activity_id INT PRIMARY KEY IDENTITY,
	activity_name VARCHAR(255),
	activity_date DATE
);

INSERT INTO sales.activities(activity_name ,activity_date)
VALUES ('Marketing','2021-06-29')

INSERT INTO sales.activities(activity_name ,activity_date)
VALUES ('Advertizing',getdate())

INSERT INTO sales.activities
VALUES (NULL,'Client Visit','2021-06-29')

SELECT * FROM sales.activities;

--FOREIGN KEY
CREATE DATABASE TrainingDB;

USE TrainingDB;

CREATE SCHEMA procurement;

CREATE TABLE procurement.vendor_groups(
	group_id INT PRIMARY KEY IDENTITY,
	group_name VARCHAR(100)
);


CREATE TABLE procurement.vendor(
	vendor_id INT PRIMARY KEY IDENTITY,
	vendor_name VARCHAR(100),
	group_id INT CONSTRAINT fk_group_id FOREIGN KEY
	REFERENCES procurement.vendor_groups(group_id)
);

CREATE SCHEMA production;


CREATE TABLE production.product(
	product_id INT PRIMARY KEY IDENTITY,
	product_name VARCHAR(100),
	list_price FLOAT,
	vendor_id INT CONSTRAINT fk_vendor_id FOREIGN KEY
	REFERENCES procurement.vendor(vendor_id)
);

INSERT INTO procurement.vendor_groups(group_name)
VALUES('Third-Party Vendors'),
	('Interco Vendors'),
	('One-Time Vendors');

SELECT * FROM [procurement].vendor_groups;

INSERT INTO procurement.vendor(group_id,vendor_name) VALUES
(1, 'ABC Corp'),
(2, 'PQR Corp'),
(1, 'MNO Corp'),
(2, 'XXX Corp'),
(3, 'BBC Corp')
INSERT INTO procurement.vendor(group_id,vendor_name) VALUES
(2, 'RR Corp'),
(3, 'XYZ Corp'),
(3, 'JKL Corp')

INSERT INTO procurement.vendor(group_id,vendor_name) VALUES
(4, 'TUV Corp')
SELECT * FROM [procurement].[vendor];

DROP TABLE production.product;
CREATE TABLE production.product(
	product_id INT PRIMARY KEY IDENTITY,
	vendor_id INT CONSTRAINT fk_vendor_id FOREIGN KEY
	REFERENCES procurement.vendor(vendor_id),
	product_name VARCHAR(100) NOT NULL,
	list_price FLOAT CHECK (list_price > 0) NOT NULL,
);

INSERT INTO production.product(vendor_id , product_name , list_price) 
VALUES(1 , 'Nirma' , 25);

SELECT * FROM production.product;

--CHECKING NOT NULL
INSERT INTO production.product(vendor_id , product_name , list_price) 
VALUES(1 , NULL , 25);

--CHECKING NOT NULL
INSERT INTO production.product(vendor_id , product_name , list_price) 
VALUES(1 , NULL , NULL);

--CHECKING NOT NULL
INSERT INTO production.product(vendor_id , list_price) 
VALUES(1  , 25);

--CHECK CONSTRAINT
INSERT INTO production.product(vendor_id , product_name , list_price) 
VALUES(1 , 'Nirma' , 0);

INSERT INTO production.product(vendor_id , product_name , list_price) 
VALUES(1 , 'Nirma' , -90);

SELECT * FROM [procurement].[vendor]
SELECT * FROM [procurement].[vendor_groups]

SELECT 
	*	 
FROM
	[procurement].[vendor]
ORDER BY
	vendor_name;

SELECT 
	group_id,
	COUNT(group_id) group_count
FROM
	[procurement].[vendor]
GROUP BY
	group_id
HAVING
	COUNT(group_id) > 2;

--SQL Server Date Functions
SELECT GETDATE() DATE_TIME;
SELECT DAY(GETDATE()) [DAY];
SELECT MONTH(GETDATE()) [MONTH];
SELECT YEAR(GETDATE()) [YEAR];

USE BikeStores;
SELECT * FROM [sales].[orders];
SELECT  
	order_id , 
	order_date , 
	DAY(order_date) [day] , 
	MONTH(order_date) [month] , 
	YEAR(order_date) [year] 
FROM 
	[sales].[orders];

SELECT  
	order_id , 
	order_date , 
	DAY(order_date) [day] , 
	MONTH(order_date) [month] , 
	YEAR(order_date) [year]
FROM 
	[sales].[orders]
WHERE 
	 YEAR(order_date) = 2018;

--DATEADD()
SELECT DATEADD(SECOND, 1 , '2018-12-31 23:59:59'); 
SELECT DATEADD(DAY, 1 , '2018-12-31 23:59:59'); 
SELECT DATEADD(MONTH, 1 , '2018-12-31 23:59:59');
SELECT DATEADD(YEAR, 1 , '2018-12-31 23:59:59');

--DATEDIFF()

DECLARE 
	@start_dt DATETIME2 = '2019-12-31 23:59:59.9999999',
	@end_dt DATETIME2 = '2020-01-01 00:00:00.0000000';

SELECT 
	DATEDIFF(YEAR , @start_dt , @end_dt) diff_in_year,
	DATEDIFF(QUARTER , @start_dt , @end_dt) diff_in_quarter,
	DATEDIFF(MONTH , @start_dt , @end_dt) diff_in_month,
	DATEDIFF(DAY, @start_dt , @end_dt) diff_in_day,
	DATEDIFF(WEEK , @start_dt , @end_dt) diff_in_week,
	DATEDIFF(HOUR , @start_dt , @end_dt) diff_in_hour,
	DATEDIFF(MINUTE , @start_dt , @end_dt) diff_in_min,
	DATEDIFF(SECOND , @start_dt , @end_dt) diff_in_sec,
	DATEDIFF(MILLISECOND , @start_dt , @end_dt) diff_in_mills;

--SQL Date Conversions

SELECT CONVERT(varchar, getdate(),1);
SELECT CONVERT(varchar, getdate(),2);
SELECT CONVERT(varchar, getdate(),3);
SELECT CONVERT(varchar, getdate(),5);
SELECT CONVERT(varchar, getdate(),6);
SELECT CONVERT(varchar, getdate(),7);
SELECT CONVERT(varchar, getdate(),10);
SELECT CONVERT(varchar, getdate(),11);
SELECT CONVERT(varchar, getdate(),12);
SELECT CONVERT(varchar, getdate(),13);
SELECT CONVERT(varchar, getdate(),14);
SELECT CONVERT(varchar, getdate(),15);
SELECT CONVERT(varchar, getdate(),18);

--SQL Server String Functions
SELECT ASCII('A');
SELECT ASCII('Z');

SELECT ASCII('a');
SELECT ASCII('z');
SELECT CHARINDEX('LL' ,'HELLO');
SELECT CHARINDEX('A' ,'HELLO');
SELECT LEFT('RICHARD',4)
SELECT UPPER('hello');
SELECT LOWER('RICHARD')
SELECT LEN('VIVEK');
SELECT LTRIM('                                                   SQL');
SELECT LEN(RTRIM('SQL                                                   '));
SELECT LEN('SQL                ');
SELECT CONCAT('SQL ','Server');
SELECT DATALENGTH('SQL                ');

--SQL SERVER COMPUTED COLUMNS
SELECT 
	order_id,
	quantity,
	list_price,
	quantity * list_price total_amount,
	discount,
	(quantity * list_price) * discount calculated_discount,
	( (quantity * list_price) - (quantity * list_price) * discount ) final_bill_amount
FROM
	[sales].[order_items];

--SQL Index
	--type of index
		--1.Clustered Index - only one  - B- tree - Phy sort the data
		--2.Non-Clustered Index - multiple 

DROP TABLE production.parts; 
CREATE TABLE production.parts(
	part_id INT NOT NULL,
	part_name VARCHAR(40)
);		

INSERT INTO 
	production.parts(part_id,part_name)
VALUES
	(1,'Frame'),
	(3,'Head Tube');

SELECT * FROM production.parts;

INSERT INTO 
	production.parts(part_id,part_name)
VALUES
	(4,'Break Grip');

CREATE CLUSTERED INDEX ix_parts_part_id
ON production.parts(part_id);

CREATE INDEX ix_parts_part_name
ON production.parts(part_name);

--Case 
--1 = PENDING
--2 = PROCESSING
--3 = REJECTED
--4 = COMPLETED

SELECT
	*
FROM
	[sales].[orders]

-----------------------------
SELECT 
	order_status,
	count(order_id) order_count
FROM
	sales.orders
WHERE
	YEAR(order_date) = 2018
GROUP BY
	order_status;

SELECT 
	CASE order_status
		WHEN 1 THEN 'Pending'
		WHEN 2 THEN 'Processing'
		WHEN 3 THEN 'Rejected'
		WHEN 4 THEN 'Completed'
	END AS order_status_details,
	count(order_id) order_count
FROM
	sales.orders
WHERE
	YEAR(order_date) = 2018
GROUP BY
	order_status;
	
--View
SELECT
	*
FROM
	[production].[products];

CREATE VIEW products_vw
AS
	SELECT
	product_id,product_name, list_price
FROM
	[production].[products];	

select * from products_vw;

SELECT 
	product_name , 
	list_price
FROM
	products_vw;

CREATE VIEW order_details
AS
SELECT 
	CASE order_status
		WHEN 1 THEN 'Pending'
		WHEN 2 THEN 'Processing'
		WHEN 3 THEN 'Rejected'
		WHEN 4 THEN 'Completed'
	END AS order_status_details,
	count(order_id) order_count
FROM
	sales.orders
WHERE
	YEAR(order_date) = 2018
GROUP BY
	order_status;

SELECT 
	*
FROM
	order_details
WHERE
	order_status_details = 'Completed'
OR
	order_status_details = 'Processing';

DROP TABLE production.product;
CREATE TABLE production.product(
	product_id INT PRIMARY KEY IDENTITY,
	vendor_id INT,
	product_name VARCHAR(100) NOT NULL,
	list_price FLOAT CHECK (list_price > 0) NOT NULL,
);

SELECT 
	*
FROM
	production.product;

INSERT INTO production.product(vendor_id , product_name , list_price) 
VALUES
	(1 , 'Nirma' , 25),
	(2 , 'Lux' , 20),
	(4 , 'Godrej No 1' , 15);
	

CREATE VIEW product
AS
SELECT 
	product_id,
	product_name,
	list_price
FROM
	production.product;	

SELECT 
	*
FROM
	production.product;


SELECT 
	* 
FROM 
	product_details_wo_vender_vi;

UPDATE product_details_wo_vender_vi
SET list_price = 30
WHERE product_id = 2;

select 
	* 
from 
	product_name_price_vi
order by
	price;

SELECT 
		AVG(price)
	FROM
		product_name_price_vi



SELECT 
	*
FROM
	product_name_price_vi
WHERE price < (
	SELECT 
		AVG(price)
	FROM
		product_name_price_vi
);


SELECT 
	SUM(price)
FROM
	product_name_price_vi;

CREATE VIEW product_list_sum_vi
AS
	select 
		* 
	from 
	production.product
	select
		'total',
		sum(list_price)
	from
	production.product;	

SELECT *
FROM
Product_Name_Price_vi
 
SELECT
    SUM(Price) [Price],
    Count(Name) [Name]
FROM
    Product_Name_Price_vw


SELECT 
	*
FROM
	[sales].[orders]


